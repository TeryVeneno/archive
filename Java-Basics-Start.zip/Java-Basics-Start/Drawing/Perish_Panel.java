package perish;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;
import javax.swing.*;

public class Perish_Panel {
  private static final long serialVersionUID = 3l;
}
