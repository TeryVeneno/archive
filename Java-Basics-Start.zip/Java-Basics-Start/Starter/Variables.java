public class Variables {
  public static void main(String[] args) {
    int number = 100;
    double rate = 2.34;
    String first_name;
    char letter;
    boolean flag;

    int salary, hours_worked;
    String middle_name, last_name, initials;
    // assigning statements
    first_name = "Jane";
    number = 25 * 5;
    letter = 'a';
    flag = true;

  }
}
