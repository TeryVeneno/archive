public class Mixed_math {
  public static void main(String[] args) {
    /*double dnum = 2.2222;
    int num;
    num = dnum;
    System.out.println(dnum);*/
    int num;
    char c =  'z';
    num = c;
    System.out.print(num);
  }
}
