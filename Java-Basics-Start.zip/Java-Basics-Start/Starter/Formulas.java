/* x/ y -3
1 / (x + y)
the square root of x to the 6th plus y to the 5th
absolute value of x + y*/

public class Formulas {
  public static void main(String[] args) {
    double x,y,z;
    x = -13.0;
    // x = 13.0;
    y = 2.0;
    // z = x / (y - 3);
    // z = 1 / (x + y);
    // z = Math.sqrt(Math.pow(x,6) + Math.pow(y,5));
    z = Math.abs(x + y);
    System.out.println(z);
  }
}
