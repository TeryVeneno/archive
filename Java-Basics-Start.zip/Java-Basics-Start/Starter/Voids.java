public class Voids {
  static void Heading(String name, String date) {
    System.out.println("**************");
    System.out.println("*  " + name + "   *");
    System.out.println("*  " + date + "  *");
    System.out.println("**************");
  }

  public static void main(String[] args) {
    Heading("Simon", "7/4/18");
  }
}
