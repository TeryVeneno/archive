public class Operators {
  public static void main(String[] args) {
    System.out.println(2 + 2);
    int num1, num2;
    num1 = 120;
    num2 = 23;
    System.out.println(num1 - num2);
    System.out.println(num1 * num2);
    System.out.println(num1 / num2);
    System.out.println(120/23.0);
    System.out.println(4 % 3);
    System.out.println(4 % 2);
  }
}
