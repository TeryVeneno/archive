public class Order_ops {
  public static void main(String[] args) {
    double number = (10 - 2.0) / (14.0 + 3);
    System.out.print(number);
  }
}
