import utilities.Ran;

public class Sort {
  public static void main(String[] args) {
    Ran ran = new Ran();
    System.out.println(ran.percent_chance(0.8, 0.2));
  }
}
