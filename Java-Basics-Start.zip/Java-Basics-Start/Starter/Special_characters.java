public class Special_characters {
  public static void main(String[] args) {
    System.out.print("Hello world!");
    System.out.print("\n");
    System.out.print("Goodbye. \n");
    System.out.print("\n");
    System.out.print("Day 1\tDay 2\tDay 3\tDay 4");
    System.out.print("\t");
    System.out.println("Day 5");
  }
}
