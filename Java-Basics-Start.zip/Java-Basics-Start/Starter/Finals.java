public class Finals {
  public static void main(String[] args) {
    final double pi = 3.14159;
    double radius = 2.0;
    double area = pi * (radius * radius);
    System.out.println(area);
    final String greeting = "Hello";
  }
}
