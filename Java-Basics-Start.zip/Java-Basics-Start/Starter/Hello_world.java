public class Hello_world {
	public static void main(String[] args) {
		System.out.print("Hello ");
		System.out.println("world!");
	}
}
