import java.util.*;
import utilities.*;
public class Lotto {
 public static void main(String[] args) {
   Scanner input = new Scanner(System.in);
   Random rand = new Random(26);
   Ran ran = new Ran();
   System.out.println(rand.nextInt(60));
 }
}
