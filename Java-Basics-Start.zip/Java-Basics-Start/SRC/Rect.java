package gui;

public class Rect {
  public int x;
  public int y;
  public int height;
  public int width;

  public Rect (int xs, int ys, int heights, int widths) {
    x = xs;
    y = ys;
    height = heights;
    width = widths;
  }
}
