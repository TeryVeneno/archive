package gui;

public class Line {
  public int x1;
  public int y1;
  public int x2;
  public int y2;

  public Line (int x1s, int y1s, int x2s, int y2s) {
    x1 = x1s;
    y1 = y1s;
    x2 = x2s;
    y2 = y2s;
  }
}
