package utilities;

public class Doubles {
  public double value;
  public Doubles (double value) {
    this.value = value;
  }
}
